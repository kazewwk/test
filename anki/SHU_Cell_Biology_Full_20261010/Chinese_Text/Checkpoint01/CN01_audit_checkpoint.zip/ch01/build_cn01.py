import json, hashlib, re
from pathlib import Path

ROOT=Path('/workspace/scratch/f38d1ebe5335')
OUT=ROOT/'cn_fast/ch01'
base=json.loads((ROOT/'resume/baseline289/cards.json').read_text())['cards']
knowledge=json.loads((ROOT/'resume/baseline289/knowledge.json').read_text())
positions={x['unit_id']:x for x in json.loads((ROOT/'resume/baseline289/read_positions.json').read_text())}
COMMIT='1cca4eb09d83ec631136f60e9dc7dd0e05df843c'
SRC='细胞生物学第5版·丁明孝等·第1章；细胞生物学制卡/01_绪论/中文原文.md'
# This explicit set records the root's completed source-to-question-to-answer review.
# It is not a discovery loop granting verification to unreviewed input.
REVIEWED=set(range(1,81))
ranges={1:'7',2:'9–11',3:'17',4:'19、71',5:'23',6:'25–27',7:'31–39',8:'31',9:'39',10:'43、53',11:'47',12:'49、55',13:'51',14:'53',15:'55',16:'57',17:'59–61',18:'63–65',19:'69',20:'69',21:'71–75',22:'79',23:'89',24:'93',25:'97',26:'101、241',27:'105',28:'107–109',29:'109、115',30:'117、302',31:'119',32:'119',33:'123–146、393',34:'127',35:'129–130',36:'154–158、167',37:'150、162–175',38:'177、187',39:'179、245',40:'181',41:'183–185',42:'193',43:'197',44:'197',45:'199',46:'201',47:'203',48:'210–214',49:'216–218',50:'220–222',51:'235',52:'237–241',53:'249、263',54:'253',55:'257',56:'267–271',57:'273',58:'275',59:'277–279',60:'281',61:'283–285',62:'289–293',63:'295–300',64:'304–306',65:'308',66:'316–328',67:'326',68:'326',69:'326',70:'330',71:'333',72:'337–349、405',73:'353、357',74:'359',75:'361',76:'363–365',77:'369–375',78:'377',79:'93、197、302、409',80:'154–158、245–257、316–328、407'}
def src(n):return f'{SRC}，行{ranges[n]}；固定提交{COMMIT}'
def oldsrc(k):
 return '; '.join(f"细胞生物学制卡/{positions[u]['file']}，行{positions[u]['line']}，{u}" if u in positions else u for u in k.get('source_units',[]))+'；继承自289卡基线的稳定段落定位'

patches={
3:{'front':'现代生物学的三大基石分别是什么、由谁在哪年确立？细胞学说的基础意义及20世纪50年代分子生物学的推动作用是什么？'},
4:{'front':'细胞学与细胞生物学分别研究什么？比较方法、三个研究层次及主要生命过程的研究范围。'},
7:{'front':'施莱登和施万如何建立细胞学说？说明思想背景、年份和代表著作、核心结论、两人生卒年及早期繁殖解释的错误。'},
27:{'front':'根据平均直径的粗略比较，最小病毒、支原体、细菌、多数动植物细胞及一些原生动物的典型大小依次如何变化？',
 'answer':['本章以平均直径作粗略比较：支原体约比最小病毒大10倍，细菌约比支原体大10倍，多数动植物细胞约比细菌大10多倍，一些原生动物约比一般动植物细胞大10倍。这是典型数量级比较，不能作为每类所有成员的精确大小或绝对边界。'],
 'rubric':['按病毒→支原体→细菌→多数动植物细胞→一些原生动物的顺序比较；相邻约10倍或10多倍；保留平均直径、粗略与典型的限定。']},
29:{'front':'IGF/PI3K/Akt/mTOR信号网络与细胞体积有什么联系？mTOR的教材名称、酶类别、雷帕霉素敏感性及失活结果是什么？',
 'answer':['本章图注概括，多细胞生物主要通过IGF（胰岛素样生长因子）/PI3K（磷脂酰肌醇3-激酶）/Akt（蛋白激酶B）/mTOR信号途径调控细胞体积。','本版将mTOR称为哺乳动物雷帕霉素靶蛋白，是蛋白激酶，因可被雷帕霉素抑制而得名。该蛋白失活会导致细胞体积变小；这与正文关于核糖体活性、蛋白质积累参与细胞大小调控的框架相联系。'],
 'rubric':['写出IGF→PI3K→Akt→mTOR的网络成员及体积调控联系。','mTOR的教材中文名称、蛋白激酶、受雷帕霉素抑制及失活导致体积变小。']},
31:{'source_units':['CN01-S02-P021']},
34:{'front':'本版怎样估算新生儿、成人的细胞总数和人体细胞类型数？怎样区分总量、类型与估算范围？',
 'answer':['本版估计新生儿约2×10¹²个细胞、成人约3.7×10¹³个；人体有200多种不同细胞类型。前两者是总个数，200多种是类型数，两种指标不能互换。总数属于教材近似估算，不是任何个体、任何年龄的精确常数。'],
 'rubric':['新生儿约2×10¹²、成人约3.7×10¹³；200多种指类型；数量与类型、近似估算与个体常数的区别。']},
39:{'front':'青霉素作用于哪种细胞壁成分？古菌对这类靶点药物为何反应不同，革兰染色能否替代壁成分鉴定？'},
38:{'front':'细菌的典型基本结构是什么？有些细菌还可有什么特化结构，拟核与真核细胞核如何区别？',
 'answer':['本章细菌典型基本结构为细胞壁、细胞质膜、核区和核糖体，某些种还有荚膜与鞭毛。绝大多数细菌有明显但形态不规则的核区或拟核，主要遗传物质在此组织，周围为较致密的胞质。拟核没有核膜包围，不是膜围绕的典型真核细胞核。'],
 'rubric':['细胞壁、质膜、核区、核糖体；某些种才有荚膜和鞭毛；拟核无核膜、形态不规则及其与胞质的关系。']},
46:{'answer':['细菌以二分裂增殖。本章给出在适宜的快速生长条件下，大肠杆菌约20分钟增殖一代，而完成一轮DNA复制约需40分钟。连续复制轮次重叠：上一轮尚未完成，下一轮已经启动；刚分开的子细胞中DNA已完成部分复制。因此复制耗时可以超过相邻分裂间隔，不必每轮都从零开始复制整个基因组。']},
43:{'front':'细菌为什么能使复制、转录和翻译在同一空间并行？解释转录与翻译耦联的结构条件和具体过程。',
 'answer':['细菌的DNA、RNA转录装置和蛋白质合成装置在空间上没有核膜区室分隔，因此这些过程可以并行。正在转录的mRNA可同时与核糖体结合，核糖体沿新生mRNA翻译肽链，使转录与翻译在时间和空间上耦联。这不要求一段DNA每次都必须同时进行三种过程。'],
 'rubric':['无核膜区室分隔→新生mRNA可接触核糖体→尚未完成转录即可翻译肽链；复制、转录、翻译可并行而非必然同时。']},
49:{'front':'蓝细菌的包被、类囊体与藻胆体、中心质及三类内含物怎样组织，各自承担什么功能？',
 'answer':['蓝细菌质膜外有细胞壁和胶质鞘。胞质内同心环样膜片层称类囊体，光合色素和电子传递链位于类囊体；膜上的藻胆体由藻胆蛋白组成，将光能传递给叶绿素a。','中心质是DNA主要所在区域，与周围胞质没有明确界限，也不一定处于中央。不同种类和个体的DNA拷贝数变化大，有的含多个拷贝。内含物包括脂滴、羧酶体和气泡；羧酶体含固定CO₂的酶，蛋白质鞘包围的气泡调节细胞在水中的位置。'],
 'rubric':['壁与胶质鞘；类囊体定位光合色素和电子链；藻胆体向叶绿素a传能。','中心质DNA、无明确界限且非必在中央、拷贝变化；脂滴、羧酶体固碳与气泡位置调节。']},
50:{'front':'蓝细菌怎样分裂并形成多细胞群体？丝状群体在什么条件下形成异形胞，比例与固氮反应、能量来源是什么？',
 'answer':['蓝细菌细胞中部向内生长新横隔壁，将中心质和原生质分为两半。两个子细胞常在公共胶质鞘内保持联系，并持续分裂形成丝状、片状等群体。某些丝状蓝细菌在氮源不足时，群体中约5%—10%的细胞分化成异形胞。','异形胞中的固氮酶将N₂还原为NH₃，本章将所需ATP联系到光系统Ⅰ提供的能量。应保留丝状类群、氮源不足和部分细胞分化的条件。'],
 'rubric':['新横隔壁分配中心质与原生质、公共胶质鞘保持群体；丝状、氮不足、5%—10%。','固氮酶、N₂→NH₃、ATP及光系统Ⅰ的能量联系；不是所有蓝细菌全部细胞都分化。']},
53:{'front':'比较典型细菌与古菌膜脂的甘油连接键；古菌C₂₀双层与部分嗜热古菌C₄₀单层有何差别，非极性脂质是什么来源？',
 'answer':['典型细菌的脂肪酸通过酯键与甘油结合，古菌的烃链通过醚键与甘油结合。本章图注概括C₂₀甘油二醚脂构成双层膜，其中镶嵌膜蛋白；某些嗜热古菌的C₄₀甘油四醚脂与膜蛋白组成单层膜，利于抵抗高温。','古菌膜还可含鲨烯衍生物等非极性脂质。单层膜应限于本章所述特定嗜热古菌，不能扩大为所有古菌的共有结构。'],
 'rubric':['细菌酯键与古菌醚键；C₂₀双层、C₄₀单层及膜蛋白；部分嗜热与耐高温。','鲨烯衍生物等非极性脂质；单层膜的类群范围限定。']},
58:{'answer':['DNA与组蛋白构成核小体，本章给直径约10 nm；进一步组织为紧密程度不同的常染色质与异染色质，分裂阶段形成染色体。染色质结构、DNA修饰相关酶与转录因子共同调控转录。','核仁主要参与rRNA转录和核糖体亚基装配。核糖体由rRNA和多种蛋白组成，按mRNA的指令，将tRNA携带的氨基酸连接成肽链，实现信息表达。']},
59:{'answer':['胞质骨架包括微丝、微管和中间纤维。本章微丝直径5—7 nm，联系细胞运动与信号传递；微管直径24 nm，为胞内运输提供轨道并形成有丝分裂纺锤丝；中间纤维直径约10 nm，类型多、有组织特异性，主要提供机械支撑。','本章核骨架包括核纤层与核基质，前者主要由核纤层蛋白lamin组成，后者成分复杂，两者与基因表达、染色质构建和排布有关。核骨架与胞质骨架相联系，维持细胞形态与内部空间布局。']},
62:{'front':'动物和植物细胞有哪些基本共性？植物的自养、定植生活如何联系细胞壁成分、胞间连丝、液泡与质体？',
 'answer':['动物和植物细胞具有基本相同的真核结构和功能体系，大部分细胞器形态、成分及功能相近。植物自养并定植生活，在细胞壁、液泡及光合质体等方面体现相应的结构和功能特征。','植物壁主要为纤维素，还含果胶、半纤维素与木质素等；相邻细胞通过胞间连丝联系。液泡参与体积增加、膨压维持和胞内储存降解；叶绿体是光合作用的质体。这些特征应联系营养和生存方式，而非仅记结构名称。'],
 'rubric':['基本相同的真核结构功能与大部分细胞器共性；植物自养定植与壁、液泡、质体联系。','壁的纤维素、果胶、半纤维素、木质素；胞间连丝；液泡与叶绿体功能。']},
71:{'front':'本章图注描述小鼠回肠末端分节丝状菌通过哪条细胞和细胞因子作用链增强宿主抵御致病菌的能力？',
 'answer':['本章图注描述，定植于小鼠回肠末端的分节丝状菌能刺激Th17辅助性T细胞增殖，并分泌IL-17等细胞因子，从而加强宿主对致病菌的抵御能力。此处是图注给出的功能结论。'],
 'rubric':['小鼠回肠末端分节丝状菌→Th17增殖→IL-17等细胞因子→增强抵御致病菌。']},
72:{'rubric':['病毒为非细胞复合体、绝大多数20—200nm、需电镜；缺独立核糖体与完整代谢。','细胞双链DNA与RNA；病毒DNA或RNA及通常限定；病毒复制合成装配与细胞分裂的区别。','利用宿主的结构、原料、能量、相关酶；某些病毒核酸可在适宜细胞中形成子代；细胞仍是基本单位。'],'answer':['病毒是核酸与蛋白等构成的非细胞复合体，本章概括绝大多数大小20—200 nm，需电镜清楚观察，没有独立核糖体和完整代谢装置；细胞则组织完整的基本生命活动。','细胞生命以双链DNA作为遗传物质，并有RNA参与信息表达；不同病毒的基因组可为DNA或RNA，通常一种病毒粒子只含相应一种基因组核酸。病毒在宿主内合成核酸与蛋白，再装配形成子代；细胞通常通过分裂形成后代。','病毒必须利用宿主细胞的结构、原料、能量与相关酶体系表现增殖和遗传，属于彻底的寄生，可称分子水平寄生。某些病毒的核酸进入适宜宿主即可形成正常子代，说明病毒遗传信息仍需借细胞装置执行。因此病毒不推翻细胞是生命活动基本单位的结论。']},
73:{'front':'衣壳、核衣壳与囊膜分别是什么，其组成、功能和来源如何区别？比较本章腺病毒、疱疹病毒与烟草花叶病毒的核酸及包被特点。',
 'answer':['衣壳是保护病毒核酸的蛋白质外壳；核衣壳由核酸和衣壳构成。有些病毒在核衣壳外还有脂双层囊膜，主要成分为脂质和蛋白质，膜脂来自宿主细胞膜，相关蛋白由病毒基因编码。衣壳与囊膜不是同一结构。','本章文字图注中，腺病毒由DNA和衣壳组成；疱疹病毒的核衣壳外有脂双层囊膜；烟草花叶病毒属于RNA病毒。'],
 'rubric':['衣壳蛋白保护核酸；核衣壳=核酸+衣壳；某些病毒有囊膜，其脂质与蛋白来源。','腺病毒DNA和衣壳、疱疹病毒外有囊膜、烟草花叶病毒为RNA病毒。']},
75:{'front':'概括病毒在宿主细胞内增殖的基本阶段：进入后怎样利用细胞形成子代并传播？为什么步骤描述要保留病毒类型差异？',
 'answer':['病毒首先识别并进入适宜宿主，随后利用细胞中的相关代谢装置，以病毒核酸信息为基础完成核酸复制及表达，翻译病毒蛋白，再由核酸和蛋白等装配成子代病毒颗粒；子代从细胞释放，继而感染其他细胞。','本章说明病毒可以通过不同途径进入细胞，因此上述只是功能阶段的概括，不能推出所有病毒都以同一种胞饮途径进入，或在相同细胞位置使用相同酶完成复制。'],
 'rubric':['识别进入→核酸复制与表达→蛋白合成→装配→释放→再感染；依赖适宜宿主装置。','不同病毒存在进入与复制方式差异；基本功能阶段不等于统一具体机制。']},
}
# These image-only bindings are intentionally excluded from this text release.
media_kp=set(range(134,142))|{146,147,148,149,151,153}|set(range(184,190))|{205,229,230,263,276,277,294,346,347,348,349,407,410,411,428,429,430,431}|set(range(436,445))
media_kp.discard(294)
pending_verification={294}
english_kp={656}
K={k['knowledge_id']:k for k in knowledge}
cards=[]; coverage=[]; cardmap={}; anchor_map={}
for old in base:
 if not old['id'].startswith('RB-CN01-'): continue
 n=int(old['id'].split('-')[-1])
 if n not in REVIEWED or n==35:continue
 c=dict(old);p=patches.get(n,{})
 newtask=n in {27,29,34,38,43,49,50,53,62,71,73,75}
 cid=f'CT-CN01-{n:04d}' if newtask else old['id']
 a=p.get('answer',[v['text'] for v in c['answer']]);r=p.get('rubric',[v['text'] for v in c['rubric']])
 ids=[kid for kid in c['knowledge_ids'] if int(kid.split('-')[-1]) not in media_kp|pending_verification|english_kp]
 obj={'id':cid,'kind':'basic','deck':'上海大学生物学::细胞生物学第5版·中文正文::01_绪论','front':p.get('front',c['front']),'answer':'\n\n'.join(a),'rubric':r,'source':src(n),'source_mode':'inferred' if n in {3,8,26,27,31,43,53,61,66,67,68,69,74,75,77,79,80} else 'direct','knowledge_ids':ids,'tags':['细胞生物学','CN01','中文正文','机制问答'],'verified':True,'review_receipt':{'reviewer':'root','actual_text_read':'source.md L1–421；正文、文字图注、表1-1全部33个比较单元格、思考题均实读','basis':'旧任务逐张复核后继承；指定任务按新文本改写','original_card_id':old['id'],'original_guid_reused':False}}
 cards.append(obj);cardmap[old['id']]=obj;anchor_map[cid]=(a,r)
 for kid in ids:
  k=K[kid];aa=int(k['answer_anchor'][1:])-1;rr=int(k['rubric_anchor'][1:])-1
  aq=a[min(aa,len(a)-1)];rq=r[min(rr,len(r)-1)]
  point=k['knowledge']
  if kid=='KP-CN01-0292':point='古菌膜中的鲨烯衍生物等非极性脂质'
  if kid=='KP-CN01-0407':raise AssertionError('image location should not be covered')
  coverage.append({'id':kid,'source':src(n),'point':point,'status':'covered','bindings':[{'card_id':cid,'answer_quote':aq,'rubric_quote':rq,'recall_prompt':obj['front']}],'evidence_mode':'old_anchor_rechecked_against_fixed_Chinese_text'})

def add_point(n,num,point,aq,rq):
 c=cardmap[f'RB-CN01-{n:04d}'];kid=f'CK-CN01-{num:04d}';c['knowledge_ids'].append(kid)
 coverage.append({'id':kid,'source':src(n),'point':point,'status':'covered','bindings':[{'card_id':c['id'],'answer_quote':aq,'rubric_quote':rq,'recall_prompt':c['front']}],'evidence_mode':'fresh_Chinese_text_review'})
add_point(27,1,'最小病毒至一些原生动物的典型直径逐级约10倍的粗略关系','支原体约比最小病毒大10倍，细菌约比支原体大10倍，多数动植物细胞约比细菌大10多倍，一些原生动物约比一般动植物细胞大10倍','相邻约10倍或10多倍')
add_point(27,2,'平均直径粗略比较不能定义类群的绝对尺寸边界','这是典型数量级比较，不能作为每类所有成员的精确大小或绝对边界','保留平均直径、粗略与典型的限定')
add_point(29,3,'中文文字图注中的体积调控网络成员','IGF（胰岛素样生长因子）/PI3K（磷脂酰肌醇3-激酶）/Akt（蛋白激酶B）/mTOR信号途径调控细胞体积','IGF→PI3K→Akt→mTOR')
add_point(62,4,'植物与动物基本真核结构功能的共性','动物和植物细胞具有基本相同的真核结构和功能体系，大部分细胞器形态、成分及功能相近','基本相同的真核结构功能与大部分细胞器共性')
add_point(73,5,'三种病毒的文字图注所示核酸与包被特点','腺病毒由DNA和衣壳组成；疱疹病毒的核衣壳外有脂双层囊膜；烟草花叶病毒属于RNA病毒','腺病毒DNA和衣壳、疱疹病毒外有囊膜、烟草花叶病毒为RNA病毒')
add_point(75,6,'病毒利用适宜宿主完成复制表达合成装配释放的功能阶段','完成核酸复制及表达，翻译病毒蛋白，再由核酸和蛋白等装配成子代病毒颗粒；子代从细胞释放，继而感染其他细胞','核酸复制与表达→蛋白合成→装配→释放→再感染')
add_point(75,7,'功能阶段的共同概括不推出全部病毒同一种具体途径','上述只是功能阶段的概括，不能推出所有病毒都以同一种胞饮途径进入，或在相同细胞位置使用相同酶完成复制','基本功能阶段不等于统一具体机制')

covered={x['id'] for x in coverage}
for k in knowledge:
 kid=k['knowledge_id'];num=int(kid.split('-')[-1])
 if not any(u.startswith('CN01') for u in k.get('source_units',[])) or kid in covered or num in english_kp:continue
 if k.get('card_id') and k['card_id'] not in cardmap and int(k['card_id'].split('-')[-1])>80:continue
 if num in media_kp or k.get('card_id')=='RB-CN01-0035' or num==269:
  status='pending_media';reason='本轮优先中文正文；此知识点涉及原图标注、图像证据或具体读图操作，未在当前文本包宣称完成。'
 elif num in {470,471,472}:
  status='unread';reason='现存中文原文仅引用知识窗数字课程，未提供知识窗完整内容；待取得实际来源。'
 else:
  status='pending_verification';reason='保留原有真实疑点：教材存在时效、绝对化、机制或OCR歧义；本轮不将未核实内容制为确定事实。'
 coverage.append({'id':kid,'point':k['knowledge'],'source':oldsrc(k),'status':status,'bindings':[],'reason':reason,'inherited_status':k.get('status')})

# The reference list is metadata, not omitted examinable science.
coverage.append({'id':'CK-CN01-DOUBT-01','source':f'{SRC}，行322；固定提交{COMMIT}','point':'环状单倍性到线状多倍性作为所有原核与真核的必然对应','status':'pending_verification','bindings':[],'reason':'DNA拓扑与细胞倍性不能简单等同；教材绝对化概括待一手材料核实，不制为确定事实。'})
coverage.append({'id':'CK-CN01-DOUBT-02','source':f'{SRC}，行322；固定提交{COMMIT}','point':'基因间隔序列和内含子均不编码任何RNA的概括','status':'pending_verification','bindings':[],'reason':'本段对非编码序列的措辞存在范围疑点，不能混同不编码蛋白与不被转录；局部暂缓。'})
coverage.append({'id':'CK-CN01-DOUBT-03','source':f'{SRC}，行330；固定提交{COMMIT}','point':'肠道菌群必需氨基酸合成对宿主营养的准确贡献范围','status':'pending_verification','bindings':[],'reason':'现有学习卡保留稳定的共生与营养免疫功能；教材必需氨基酸贡献的范围另待核实。'})
coverage.append({'id':'CK-CN01-REF','source':f'{SRC}，行383–421；固定提交{COMMIT}','point':'推荐教材与参考文献的书目元数据','status':'nonknowledge','bindings':[],'reason':'书目元数据保留于教材来源；不转换为无意义背诵任务。'})
image_lines=[n for n,s in enumerate((OUT/'source.md').read_text().splitlines(),1) if '![](' in s]
for i,n in enumerate(image_lines,1):
 coverage.append({'id':f'CK-CN01-IMG-{i:02d}','source':f'{SRC}，行{n}；固定提交{COMMIT}','point':f'中文原图行{n}逐项视觉核查与匹配图卡','status':'pending_media','bindings':[],'reason':'用户授权中文正文先交付；本轮未重新逐项读原图，媒体和视觉主动回忆后补。'})
payload={'scope_id':'SHU_CELL_CN_TEXT_20261010','cards':cards}
assert all(c['knowledge_ids'] for c in cards)
for c in cards:
 assert not re.search(r'需看图|读图|看下图|下图|待核实|再核对',c['front']+c['answer']),c['id']
OUT.joinpath('cards.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
OUT.joinpath('coverage.json').write_text(json.dumps({'knowledge':coverage},ensure_ascii=False,indent=2))
counts={s:sum(k['status']==s for k in coverage) for s in sorted({k['status'] for k in coverage})}
report={'chapters':['CN01'],'cards':len(cards),'knowledge_status':counts,'source_commit':COMMIT,'source_sha256':hashlib.sha256((OUT/'source.md').read_bytes()).hexdigest(),'read_scope':'中文原文L1–421，含正文、文字图注、表1-1全部格项、5道思考题。未重读原图和未提供的数字知识窗。','fresh_vs_inherited':'原289基线CN01主体任务逐张实读复核；视觉绑定后移，12个任务改写采用CT身份；7个新文字知识点。原包身份未冒用。','completion_claim':'第1章中文可确认主体；局部存疑和原图任务准确单列，不声称无缺口。'}
OUT.joinpath('scope_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
