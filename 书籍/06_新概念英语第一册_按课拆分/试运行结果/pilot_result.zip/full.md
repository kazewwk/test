## CONTENTS 目录

To the teacher and student
Learning a foreign language in the classroom
About this course
How to use this course
致教师和学生
外语的课堂教学
关于本教材的说明
本教材使用说明
Lesson 1 Excuse me! 对不起！
Lesson 2 Is this your ...? 这是你的……吗？
Lesson 3 Sorry, sir. 对不起，先生。
Lesson 4 Is this your ...? 这是你的……吗？
Lesson 5 Nice to meet you. 很高兴见到你。
Lesson 6 What make is it? 它是什么牌子的？
Lesson 7 Are you a teacher? 你是教师吗？
Lesson 8 What's your job? 你是做什么工作的？
Lesson 9 How are you today? 你今天好吗？
Lesson 10 Look at ... 看……
Lesson 11 Is this your shirt? 这是你的衬衫吗？
Lesson 12 Whose is this ...? This is my/your/his/her ... 这……是谁的？这是我的／你的／他的／她的……
Whose is that ...? That is my/your/his/her ... 那……是谁的？那是我的／你的／他的／她的……
Lesson 13 A new dress 一件新连衣裙
Lesson 14 What colour is your ...? 你的……是什么颜色的？
Lesson 15 Your passports, please. 请出示你们的护照。
Lesson 16 Are you ...? 你是……吗？
Lesson 17 How do you do? 你好！
Lesson 18 What are their jobs? 他们是做什么工作的？
Lesson 19 Tired and thirsty 又累又渴
Lesson 20 Look at them! 看看他／它们！
Lesson 21 Which book? 哪一本书？
Lesson 22 Give me/him/her/us/them a ... 给我／他／她／我们／他们一……、
Which one? 哪一……？
Lesson 23 Which glasses? 哪几只杯子？
Lesson 24 Give me/him/her/us/them some ... 给我／他／她／我们／他们一些……
Which ones? 哪些？
Lesson 25 Mrs. Smith's kitchen 史密斯太太的厨房
Lesson 26 Where is it? 它在哪里？
Lesson 27 Mrs. Smith's living room 史密斯太太的客厅
Lesson 28 Where are they? 它们在哪里？
Lesson 29 Come in, Amy. 进来，艾米。
Lesson 30 What must I do? 我应该做什么？

Lesson 31 Where's Sally? 萨莉在哪里？
Lesson 32 What's he/she/it doing? 他／她／它正在做什么？
Lesson 33 A fine day 晴天
Lesson 34 What are they doing? 他们在做什么？
Lesson 35 Our village 我们的村庄
Lesson 36 Where ...? ……在哪里？
Lesson 37 Making a bookcase 做书架
Lesson 38 What are you going to do? 你准备做什么？
What are you doing now? 你现在正在做什么？
Lesson 39 Don't drop it! 别摔了！
Lesson 40 What are you going to do? 你准备做什么？
I'm going to ... 我准备……
Lesson 41 Penny's bag 彭妮的提包
Lesson 42 Is there a ... in/on that ...? 在那个……中／上有一个……吗？
Is there any ... in/on that ...? 在那个……中／上有……吗？
Lesson 43 Hurry up! 快点！
Lesson 44 Are there any ...? 有些……吗？
Is there any ...? 有些……吗？
Lesson 45 The boss's letter 老板的信
Lesson 46 Can you ...? 你能……吗？
Lesson 47 A cup of coffee 一杯咖啡
Lesson 48 Do you like ...? 你喜欢……吗？
Do you want ...? 你想要……吗？
Lesson 49 At the butcher's 在肉店
Lesson 50 He likes ... 他喜欢……
But he doesn't like ... 但是他不喜欢……
Lesson 51 A pleasant climate 宜人的气候
Lesson 52 What nationality are they? 他们是哪国人？
Where do they come from? 他们来自哪个国家？
Lesson 53 An interesting climate 有趣的气候
Lesson 54 What nationality are they? 他们是哪国人？
Where do they come from? 他们来自哪个国家？
Lesson 55 The Sawyer family 索耶一家人
Lesson 56 What do they usually do? 他们通常做什么？
Lesson 57 An unusual day 很不平常的一天
Lesson 58 What's the time? 几点钟？
Lesson 59 Is that all? 就这些吗？
Lesson 60 What's the time? 几点钟？
Lesson 61 A bad cold 重感冒
Lesson 62 What's the matter with them? 他们怎么啦？
What must they do? 他们该怎么办？
Lesson 63 Thank you, doctor. 谢谢你，医生。
Lesson 64 Don't ...! 不要……！
You mustn't ...! 你不应该……！
Lesson 65 Not a baby 不是一个孩子
Lesson 66 What's the time? 几点钟？
Lesson 67 The weekend 周末

## New words and expressions 生词和短语

umbrella /ʌm'brelə/ n. 伞

number /'nʌmbə/ n. 号码

please /pliːz/ int. 请

five /faɪv/ num. 五

here /hɪə/ adv. 这里

sorry /'spri/ adj. 对不起的

my /maɪ/ possessive adjective 我的

ticket /'tɪkɪt/ n. 票

sir /sɜː/ n. 先生

cloakroom /'kləʊkrʊm/ n. 衣帽存放处

## Notes on the text 课文注释

1 Here's 是 Here is 的缩写形式，类似的例子有 He's (He is), It's (It is) 等。缩写形式和非缩写形式在英语的书面用语和口语中均有，但非缩写形式常用于比较正式的场合。

2. Sorry = I'm sorry. 这是口语中的缩略形式，用于社交场合，向他人表示歉意。

3 sir, 先生，这是英美人对不相识的男子、年长者或上级的尊称。

4 Is this it?

本句中 it 是指 your umbrella。由于前面提到了，后面就用代词 it 来代替，以免重复。

## 参考译文

请把我的大衣和伞拿给我。

这是我（寄存东西）的牌子。

谢谢，先生。

是5号。

这是您的伞和大衣。

这不是我的伞。

对不起，先生。

这把伞是您的吗？

不；不是！

这把是吗？

是，是这把。

非常感谢。